create FUNCTION admin_login(u_name admin.username%type, passwd admin.password%type)
return number --return 0 if admin doesn't exist, else return the admin id
is
admin_id NUMBER(10);
BEGIN
    SELECT id INTO admin_id FROM admin WHERE USERNAME=u_name and PASSWORD = passwd;
    RETURN admin_id;
EXCEPTION
    WHEN no_data_found THEN
    RETURN 0;
END;
/

