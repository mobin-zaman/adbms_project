create trigger PROJECT
    before insert
    on PROJECT
    for each row
BEGIN
        SELECT project_seq.nextval INTO :NEW.id FROM dual;
    end;
/

