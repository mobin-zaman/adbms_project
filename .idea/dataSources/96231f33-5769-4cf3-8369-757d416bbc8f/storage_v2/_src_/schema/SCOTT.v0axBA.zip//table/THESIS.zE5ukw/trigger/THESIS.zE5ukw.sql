create trigger THESIS
    before insert
    on THESIS
    for each row
BEGIN
        SELECT thesis_seq.nextval INTO :NEW.id FROM dual;
    end;
/

