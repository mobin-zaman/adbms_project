create trigger UNIVERSITY
    before insert
    on UNIVERSITY
    for each row
BEGIN
        SELECT university_seq.nextval INTO :NEW.id FROM dual;
    end;
/

