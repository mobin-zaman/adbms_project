create trigger DEPARTMENT
    before insert
    on DEPARTMENT
    for each row
BEGIN
        SELECT department_seq.nextval INTO :NEW.id FROM dual;
    end;
/

