create PACKAGE util AS
    function department_validity(did number)
        return boolean;
end util;
/

