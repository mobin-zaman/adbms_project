create PACKAGE BODY faculty_package AS
    --test the procedure
    PROCEDURE insert_faculty(f_name in varchar2, f_email in varchar2, f_phone_number in number, did in number) AS
    BEGIN
        if not (util.department_validity(did)) then
            raise_application_error(-2600, 'department id invalid');
        end if;

        insert into faculty(name, email, phone, dept_id) values (f_name, f_email, f_phone_number, did);

    end;

    PROCEDURE edit_faculty(f_name in varchar2, f_email in varchar2, f_phone_number in number, did in number) AS
        faculty_id number(10);
    BEGIN
        faculty_id :=
                check_faculty_validity(f_name, f_email, f_phone_number, did); --TODO: need to check when exception happen in function scope
        update faculty
        set name = f_name, email = f_email, phone = f_phone_number, DEPT_ID = did
        where id = faculty_id; 
    END;

    function check_faculty_validity(f_name in varchar2, f_email in varchar2, f_phone_number in number, did in number)
        RETURN number
        IS
        faculty_id number(10);
    BEGIN
        select id
        into faculty_id
        from faculty
        where name = f_name and email = f_email and phone = f_phone_number and dept_id = did;
        return faculty_id;
    EXCEPTION
        WHEN no_data_found THEN
            return 0;
    END;
END faculty_package;
/

