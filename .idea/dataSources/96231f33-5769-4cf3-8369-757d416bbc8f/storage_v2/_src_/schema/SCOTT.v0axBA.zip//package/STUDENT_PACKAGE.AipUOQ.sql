create PACKAGE student_package AS
    PROCEDURE insert_student(s_name in varchar2, s_email in varchar2, s_phone_number in number, did in number,
                             a_year in number);
    PROCEDURE update_student(s_id in number, s_name in varchar2, s_email in varchar2, s_phone_number in number,
                             did in number,
                             a_year in number);
END student_package;
/

