create PACKAGE faculty_package AS
    PROCEDURE insert_faculty(f_name in varchar2, f_email in varchar2, f_phone_number in number, did in number);
END faculty_package;
/

