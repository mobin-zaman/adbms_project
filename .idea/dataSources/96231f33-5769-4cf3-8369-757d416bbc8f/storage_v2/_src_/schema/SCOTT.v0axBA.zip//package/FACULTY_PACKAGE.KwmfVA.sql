create PACKAGE faculty_package AS
    PROCEDURE insert_faculty(f_name in varchar2, f_email in varchar2, f_phone_number in number, did in number);
    PROCEDURE edit_faculty(f_name in varchar2, f_email in varchar2, f_phone_number in number, did in number);
    function check_faculty_validity(f_name in varchar2, f_email in varchar2, f_phone_number in number, did in number) return number; --returns the valid of the faculty, 0 on exception
END faculty_package;
/

